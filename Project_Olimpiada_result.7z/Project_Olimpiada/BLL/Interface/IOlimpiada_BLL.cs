﻿using BLL.Model;
using DLL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Interface
{
    public interface IOlimpiada_BLL<T1, T2, T3, T4, T5>
        where T1 : class // olympics
        where T2 : class // country
        where T3 : class // participant
        where T4 : class // result
        where T5 : class // sport
    {
        public List<T1> getAllOlympics();
        public List<T2> getAllCountry();
        public List<T3> getAllParticipant();
        //public IEnumerable<T4> getAllResult();
        public List<T5> getAllSport();
        public T1 getElementOlympics(int id);
        public void createOlympics(T1 olympics);
        public void removeOlympics(int id);
        public void createSport(T5 olympics);
        public void removeSport(int id);
        public void createCountry(T2 olympics);
        public void removeCountry(int id);
        public void createParticipant(T3 olympics);
        public void removeParticipant(int id);
    }
}
