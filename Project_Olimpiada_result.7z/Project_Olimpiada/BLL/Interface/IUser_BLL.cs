﻿using BLL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Interface
{
    public interface IUser_BLL<T> where T : class
    {
        public T activiti_user {  get; set; }
        public T getUser(int id);
        public T getUser(string username, string password);
        public bool DoesUserExist(string username);
        public void ResetPassword(string username, string secretWord, string newPassword);
        public bool isEnableAccount(string username, string password);
        public void CreateUser(T user);
        public void ChangeUserData_(int id, string? username = null, string? password = null, string? secretWord = null);
        public void RemoveUser(int id);
        public void RemoveUser(T user);
    }
}
