﻿using DLL;
using DLL.Interface;
using DLL.Model;
using DLL.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Configuration
{
    public static class ConfigurationBLL
    {
        public static void ConfigurationServiceCollection(ServiceCollection services, string connectionstring)
        {
            services.AddTransient(typeof(IUser_DLL<User_Model_DLL>), typeof(User_repository));
            services.AddTransient(typeof(IOlimpiada_DLL<
            Olympics_ModelDLL,
            Country_ModelDLL,
            Participant_ModelDLL,
            Result_ModelDLL,
            Sport_ModelDLL>), typeof(Olympiada_repository));

            services.AddDbContext<Olimpiada_context>(opt => opt.UseSqlServer(connectionstring));
        }
    }
}
