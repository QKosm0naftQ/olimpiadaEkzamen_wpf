﻿using BLL.Interface;
using BLL.Model;
using DLL.Interface;
using DLL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Service
{
    public class User_service : IUser_BLL<User_Model_BLL>
    {
        private IUser_DLL<User_Model_DLL> user_dll;
        public User_Model_BLL activiti_user { get ; set; }
        public User_service(IUser_DLL<User_Model_DLL> _DLL)
        {
            user_dll = _DLL;
        }
        public User_Model_BLL getUser(int id)
        {
            return Convert_UserDLL_to_UserBLL(user_dll.getUser(id));
        }
        public User_Model_BLL getUser(string username,string password)
        {
            return Convert_UserDLL_to_UserBLL(user_dll.getUser(username, password));
        }

        public void ChangeUserData_(int id, string? username = null, string? password = null, string? secretWord = null)
        {
            throw new NotImplementedException();
        }

        public void CreateUser(User_Model_BLL user)
        {
            user_dll.CreateUser(Convert_UserBLL_to_UserDLL(user));
        }

        public bool DoesUserExist(string username)
        {
            return user_dll.DoesUserExist(username);
        }

        public bool isEnableAccount(string username, string password)
        {
            return user_dll.isEnableAccount(username, password);
        }

        public void RemoveUser(int id)
        {
            user_dll.RemoveUser(id);
        }

        public void RemoveUser(User_Model_BLL user)
        {
            user_dll.RemoveUser(Convert_UserBLL_to_UserDLL(user));
        }

        public void ResetPassword(string username, string secretWord, string newPassword)
        {
            user_dll.ResetPassword(username, secretWord, newPassword);
        }

        #region convertor

        private User_Model_DLL Convert_UserBLL_to_UserDLL(User_Model_BLL user)
        {
            return new User_Model_DLL()
            {
                ID = user.ID,
                Username = user.Username,
                Password = user.Password,
                SecretWord = user.SecretWord,
                 Role = user.Role,
            };
        }

        private User_Model_BLL Convert_UserDLL_to_UserBLL(User_Model_DLL user)
        {
            return new User_Model_BLL()
            {
                ID = user.ID,
                Username = user.Username,
                Password = user.Password,
                SecretWord = user.SecretWord,
                 Role = user.Role,
            };
        }

        #endregion


    }
}
