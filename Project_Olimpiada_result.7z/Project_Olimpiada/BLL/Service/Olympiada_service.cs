﻿using BLL.Interface;
using BLL.Model;
using DLL.Interface;
using DLL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Service
{
    public class Olympiada_service : IOlimpiada_BLL<
            Olympics_ModelBLL,
            Country_ModelBLL,
            Participant_ModelBLL,
            Result_ModelBLL,
            Sport_ModelBLL>
    {
        private IOlimpiada_DLL<
            Olympics_ModelDLL,
            Country_ModelDLL,
            Participant_ModelDLL,
            Result_ModelDLL,
            Sport_ModelDLL> olimpiada_dll;
        public Olympiada_service(IOlimpiada_DLL<
            Olympics_ModelDLL,
            Country_ModelDLL,
            Participant_ModelDLL,
            Result_ModelDLL,
            Sport_ModelDLL> _DLL)
        {
            olimpiada_dll = _DLL;
        }

        public void createOlympics(Olympics_ModelBLL olympics)
        {
            olimpiada_dll.createOlympics(Convert_OlympicsBLL_to_OlympicsDLL(olympics));
        }
        public void removeOlympics(int id)
        {
            olimpiada_dll.removeOlympics(id);
        }

        public void createSport(Sport_ModelBLL olympics)
        {
            olimpiada_dll.createSport(Convert_SportsBLL_to_SportsDLL(olympics));
        }
        public void removeSport(int id)
        {
            olimpiada_dll.removeSport(id);
        }
        public void createCountry(Country_ModelBLL olympics)
        {
            olimpiada_dll.createCountry(Convert_CountryBLL_to_CountryDLL(olympics));
        }

        public void removeCountry(int id)
        {
            olimpiada_dll.removeCountry(id);
        }

        public void createParticipant(Participant_ModelBLL olympics)
        {
            olimpiada_dll.createParticipant(Convert_ParticipantBLL_to_ParticipantDLL(olympics));
        }

        public void removeParticipant(int id)
        {
            olimpiada_dll.removeParticipant(id);
        }

        public Olympics_ModelBLL getElementOlympics(int id)
        {
            throw new NotImplementedException();
        }
        public List<Olympics_ModelBLL> getAllOlympics()
        {
             return ConvertListOlympicsDLL_to_ListOlympicsBLl(olimpiada_dll.getAllOlympics().ToList());
        }

        public List<Country_ModelBLL> getAllCountry()
        {
            return Convert_ListCountryDLL_to_ListCountryBLL(olimpiada_dll.getAllCountry().ToList());
        }

        public List<Participant_ModelBLL> getAllParticipant()
        {
            return Convert_ListParticipantDLL_to_ListParticipantBLL(olimpiada_dll.getAllParticipant().ToList());
        }
        public List<Sport_ModelBLL> getAllSport()
        {
            return Convert_ListSportsDLL_to_ListSportsBLL(olimpiada_dll.getAllSport().ToList());
        }


        #region convertor
        public Country_ModelBLL Convert_CountryDLL_to_CountryBLL(Country_ModelDLL data)
        {
            return new Country_ModelBLL() {
                Short_Name = data.Short_Name,
                City_Name = data.City_Name,
                Country_Name = data.Country_Name,
                HostCount = data.HostCount,
                Id = data.Id
            };
        }
        public Country_ModelDLL Convert_CountryBLL_to_CountryDLL(Country_ModelBLL data)
        {
            return new Country_ModelDLL()
            {
                Short_Name = data.Short_Name,
                City_Name = data.City_Name,
                Country_Name = data.Country_Name,
                HostCount = data.HostCount,
                Id = data.Id
            };
        }
        public Sport_ModelBLL Convert_SportsDLL_to_SportsBLL(Sport_ModelDLL data)
        {
            return new Sport_ModelBLL()
            {
                Id = data.Id,
                Description = data.Description,
                ParticipantCount = data.ParticipantCount,
                Sport_Name = data.Sport_Name,
            };
        }
        public Sport_ModelDLL Convert_SportsBLL_to_SportsDLL(Sport_ModelBLL data)
        {
            return new Sport_ModelDLL()
            {
                Id = data.Id,
                Description = data.Description,
                ParticipantCount = data.ParticipantCount,
                Sport_Name = data.Sport_Name,
            };
        }
        public Participant_ModelBLL Convert_ParticipantDLL_to_ParticipantBLL(Participant_ModelDLL data)
        {
            return new Participant_ModelBLL()
            {
                Id = data.Id,
                Country = data.Country,
                DateOfBirth = data.DateOfBirth,
                FullName = data.FullName,
                //SportInfo = Convert_SportsDLL_to_SportsBLL(data.SportInfo)
                //OlympicInfo = Convert_OlympicsDLL_to_OlympicsBLL(data.OlympicInfo)
            };
        }
        public Participant_ModelDLL Convert_ParticipantBLL_to_ParticipantDLL(Participant_ModelBLL data)
        {
            return new Participant_ModelDLL()
            {
                Id = data.Id,
                Country = data.Country,
                DateOfBirth = data.DateOfBirth,
                FullName = data.FullName,
                //SportInfo = Convert_SportsBLL_to_SportsDLL(data.SportInfo)
                //OlympicInfo = Convert_OlympicsBLL_to_OlympicsDLL(data.OlympicInfo)
            };
        }
        public Result_ModelBLL Convert_ResultDLL_to_ResultBLL(Result_ModelDLL data)
        {
            return new Result_ModelBLL()
            {
                Id= data.Id,
                Bronze_Medal = data.Bronze_Medal,
                //ParticipantsInfo = Convert_ParticipantDLL_to_ParticipantBLL(data.ParticipantsInfo),
                //ParticipantsInfo = Convert_ListParticipantDLL_to_ListParticipantBLL(data.ParticipantsInfo.ToList()),
                DateAchieved = data.DateAchieved,
                Gold_Medal = data.Gold_Medal,
                Position = data.Position,
                Silver_Medal = data.Silver_Medal,
                //SportInfo = Convert_SportsDLL_to_SportsBLL(data.SportInfo),
                //OlympicInfo = Convert_OlympicsDLL_to_OlympicsBLL(data.OlympicInfo)
            };
        }
        public Result_ModelDLL Convert_ResultBLL_to_ResultDLL(Result_ModelBLL data)
        {
            return new Result_ModelDLL()
            {
                Id = data.Id,
                Bronze_Medal = data.Bronze_Medal,
                DateAchieved = data.DateAchieved,
                Gold_Medal = data.Gold_Medal,
                Position = data.Position,
                Silver_Medal = data.Silver_Medal,
                //ParticipantsInfo = Convert_ParticipantBLL_to_ParticipantDLL(data.ParticipantsInfo),
                //ParticipantsInfo = Convert_ListParticipantBLL_to_ListParticipantDLL(data.ParticipantsInfo),
                //SportInfo = Convert_SportsBLL_to_SportsDLL(data.SportInfo),
                //OlympicInfo = Convert_OlympicsBLL_to_OlympicsDLL(data.OlympicInfo)
            };
        }
        public Olympics_ModelDLL Convert_OlympicsBLL_to_OlympicsDLL(Olympics_ModelBLL ol)
        {
            return new Olympics_ModelDLL()
            {
                Id = ol.Id,
                CountryInfo = Convert_CountryBLL_to_CountryDLL(ol.CountryInfo),
                Year = ol.Year,
                IsSeasonWinter = ol.IsSeasonWinter,
                SportsInfo = Convert_SportsBLL_to_SportsDLL(ol.SportsInfo),
                ResultsInfo = Convert_ResultBLL_to_ResultDLL(ol.ResultsInfo),
                ParticipantsInfo = Convert_ParticipantBLL_to_ParticipantDLL(ol.ParticipantsInfo)
                 
            };
        }
        public Olympics_ModelBLL Convert_OlympicsDLL_to_OlympicsBLL(Olympics_ModelDLL ol)
        {
            Olympics_ModelBLL a = new Olympics_ModelBLL() 
            {
                Id = ol.Id,
                CountryInfo = Convert_CountryDLL_to_CountryBLL(ol.CountryInfo),
                Year = ol.Year,
                IsSeasonWinter = ol.IsSeasonWinter,
                SportsInfo = Convert_SportsDLL_to_SportsBLL(ol.SportsInfo),
                ParticipantsInfo = Convert_ParticipantDLL_to_ParticipantBLL(ol.ParticipantsInfo),
                ResultsInfo = Convert_ResultDLL_to_ResultBLL(ol.ResultsInfo)
            };
            return a;
        }
        #endregion
        #region List_convert

        public List<Country_ModelBLL> Convert_ListCountryDLL_to_ListCountryBLL(List<Country_ModelDLL> data)
        {
            List<Country_ModelBLL> tmp_parti = new List<Country_ModelBLL>();
            foreach (var a in data)
            {
                tmp_parti.Add(Convert_CountryDLL_to_CountryBLL(a));
            }
            return tmp_parti;
        }

        public List<Country_ModelDLL> Convert_ListCountryBLL_to_ListCountryDLL(List<Country_ModelBLL> data)
        {
            List<Country_ModelDLL> tmp_parti = new List<Country_ModelDLL>();
            foreach (var a in data)
            {
                tmp_parti.Add(Convert_CountryBLL_to_CountryDLL(a));
            }
            return tmp_parti;
        }

        public List<Sport_ModelBLL> Convert_ListSportsDLL_to_ListSportsBLL(List<Sport_ModelDLL> data)
        {
            List<Sport_ModelBLL> tmp_parti = new List<Sport_ModelBLL>();
            foreach (var a in data)
            {
                tmp_parti.Add(Convert_SportsDLL_to_SportsBLL(a));
            }
            return tmp_parti;
        }

        public List<Sport_ModelDLL> Convert_ListSportsBLL_to_ListSportsDLL(List<Sport_ModelBLL> data)
        {
            List<Sport_ModelDLL> tmp_parti = new List<Sport_ModelDLL>();
            foreach (var a in data)
            {
                tmp_parti.Add(Convert_SportsBLL_to_SportsDLL(a));
            }
            return tmp_parti;
        }

        public List<Participant_ModelBLL> Convert_ListParticipantDLL_to_ListParticipantBLL(List<Participant_ModelDLL> data)
        {
            List<Participant_ModelBLL> tmp= new List<Participant_ModelBLL>();
            foreach (var a in data)
            {
                tmp.Add(Convert_ParticipantDLL_to_ParticipantBLL(a));
            }
            return tmp;
        }

        public List<Participant_ModelDLL> Convert_ListParticipantBLL_to_ListParticipantDLL(List<Participant_ModelBLL> data)
        {
            List<Participant_ModelDLL> tmp = new List<Participant_ModelDLL>();
            foreach (var a in data)
            {
                tmp.Add(Convert_ParticipantBLL_to_ParticipantDLL(a));
            }
            return tmp;
        }

        public List<Result_ModelBLL> Convert_ListResultDLL_to_ListResultBLL(List<Result_ModelDLL> data)
        {
            List<Result_ModelBLL> tmp = new List<Result_ModelBLL>();
            foreach (var a in data)
            {
                tmp.Add(Convert_ResultDLL_to_ResultBLL(a));
            }
            return tmp;
        }

        public List<Result_ModelDLL> Convert_ListResultBLL_to_ListResultDLL(List<Result_ModelBLL> data)
        {
            List<Result_ModelDLL> tmp = new List<Result_ModelDLL>();
            foreach (var a in data)
            {
                tmp.Add(Convert_ResultBLL_to_ResultDLL(a));
            }
            return tmp;
        }

        public List<Olympics_ModelBLL> ConvertListOlympicsDLL_to_ListOlympicsBLl(List<Olympics_ModelDLL> data)
        {
            List<Olympics_ModelBLL> tmp = new List<Olympics_ModelBLL> ();
            foreach (var a in data)
            {
                tmp.Add(Convert_OlympicsDLL_to_OlympicsBLL(a));
            }
            return tmp;
        }




        #endregion
    }
}
