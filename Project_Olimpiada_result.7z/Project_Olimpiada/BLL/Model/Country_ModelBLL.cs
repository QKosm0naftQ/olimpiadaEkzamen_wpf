﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Model
{
    public class Country_ModelBLL
    {
        public int Id { get; set; }
        public string Country_Name { get; set; }
        public string City_Name { get; set; }
        public string Short_Name { get; set; } // UK, USA, UA, PL, FR
        public int HostCount { get; set; } // Кількість разів, коли країна була господарем
    }

}
