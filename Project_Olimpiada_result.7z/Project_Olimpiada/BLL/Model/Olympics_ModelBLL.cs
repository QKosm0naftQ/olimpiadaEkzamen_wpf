﻿using DLL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Model
{
    public class Olympics_ModelBLL
    {
        public int Id { get; set; }
        public int Year { get; set; }
        public bool IsSeasonWinter { get; set; } // "Літня" або "Зимова"
        public Country_ModelBLL CountryInfo { get; set; }
        public Sport_ModelBLL SportsInfo { get; set; }
        public Result_ModelBLL ResultsInfo { get; set; }
        public Participant_ModelBLL ParticipantsInfo { get; set; }

    }
}
