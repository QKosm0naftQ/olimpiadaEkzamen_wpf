﻿using DLL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Model
{
    public class Sport_ModelBLL
    {
        public int Id { get; set; }
        public string Sport_Name { get; set; }
        public string Description { get; set; }
        public int ParticipantCount { get; set; }
    }
}
