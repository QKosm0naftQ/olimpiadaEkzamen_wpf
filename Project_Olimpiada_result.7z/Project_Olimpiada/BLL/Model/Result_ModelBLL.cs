﻿using DLL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Model
{
    public class Result_ModelBLL
    {
        public int Id { get; set; }
        public int Gold_Medal { get; set; }
        public int Silver_Medal { get; set; }
        public int Bronze_Medal { get; set; }
        public int Position { get; set; }
        public DateTime DateAchieved { get; set; }
    }
        //public Sport_ModelBLL SportInfo { get; set; }
}
