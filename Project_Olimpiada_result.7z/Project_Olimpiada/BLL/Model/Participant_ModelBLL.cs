﻿using DLL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Model
{
    public class Participant_ModelBLL
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Country { get; set; }
        public DateTime DateOfBirth { get; set; }
    }
        //public Sport_ModelBLL SportInfo { get; set; }
        //public List<Olympics_ModelBLL> Olympics { get; set; } = new List<Olympics_ModelBLL>();
}
