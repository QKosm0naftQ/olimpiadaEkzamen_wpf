﻿using BLL.Interface;
using BLL.Model;
using DLL.Model;
using DLL.Repository;
using DLL;
using Project_Olimpiada.Commands;
using Project_Olimpiada.WindowGeneral;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL.Service;
using System.Windows;
using System.Windows.Input;
using DLL.Interface;
using Microsoft.EntityFrameworkCore;

namespace Project_Olimpiada.ViewModels_MainProggram
{
    public class MainPage_ViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        //--------------------------------- 
        private IOlimpiada_BLL<
            Olympics_ModelBLL,
            Country_ModelBLL,
            Participant_ModelBLL,
            Result_ModelBLL,
            Sport_ModelBLL> _olymsService;
        private IUser_BLL<User_Model_BLL> _userService;
        //--------------------------------- activiti
        public User_Model_BLL MainUser {  get; set; }

        //--------------------------------- allOlimpiadspage

        private ObservableCollection<Olympics_ModelBLL> _getAllOlympiads;
        public ObservableCollection<Olympics_ModelBLL> GetAllOlympiads
        {
            get { return _getAllOlympiads; }
            set
            {
                _getAllOlympiads = value;
                OnPropertyChanged(nameof(GetAllOlympiads));
            }
        }

        private ObservableCollection<Country_ModelBLL> _getAllCountry;
        public ObservableCollection<Country_ModelBLL> GetAllCountry
        {
            get { return _getAllCountry; }
            set
            {
                _getAllCountry = value;
                OnPropertyChanged(nameof(_getAllCountry));
            }
        }

        private ObservableCollection<Participant_ModelBLL> _getAllParticipant;
        public ObservableCollection<Participant_ModelBLL> GetAllParticipant
        {
            get { return _getAllParticipant; }
            set
            {
                _getAllParticipant = value;
                OnPropertyChanged(nameof(_getAllParticipant));
            }
        }

        private ObservableCollection<Result_ModelBLL> _getAllResult;
        public ObservableCollection<Result_ModelBLL> GetAllResult
        {
            get { return _getAllResult; }
            set
            {
                _getAllResult = value;
                OnPropertyChanged(nameof(_getAllResult));
            }
        }

        private ObservableCollection<Sport_ModelBLL> _getAllSport;
        public ObservableCollection<Sport_ModelBLL> GetAllSport
        {
            get { return _getAllSport; }
            set
            {
                _getAllSport = value;
                OnPropertyChanged(nameof(_getAllSport));
            }
        }


        ////////////////
        public Olympics_ModelBLL deleteOlympiad_tmp { get; set; }
        //
        private BaseCommand _deleteSelectedOlympiadsCommand;
        public BaseCommand DeleteSelectedOlympiadsCommand
        {
            get
            {
                return _deleteSelectedOlympiadsCommand ??= new BaseCommand(a =>
                {
                    _olymsService.removeOlympics(deleteOlympiad_tmp.Id);
                    GetAllOlympiads.Remove(deleteOlympiad_tmp);
                    deleteOlympiad_tmp = new Olympics_ModelBLL();
                });
            }
        }
        //
        private CreateOlympiadsWindow CreateOlympiadsWindow_tmp;
        //
        private BaseCommand _createOlympiadsCommand;
        public BaseCommand CreateOlympiadsCommand
        {
            get
            {
                return _createOlympiadsCommand ??= new BaseCommand(a =>
                {
                    CreateOlympiadsWindow_tmp = new CreateOlympiadsWindow(this);
                    ListAllSport = new ObservableCollection<string>(
                        GetAllSport.Select(a => a.Sport_Name.ToString()).ToList()
                    );
                    ListAllCountry = new ObservableCollection<string>(
                        GetAllCountry.Select(a => a.Country_Name.ToString()).ToList()
                    );
                    ListAllParticipant = new ObservableCollection<string>(
                        GetAllParticipant.Select(a => a.FullName.ToString()).ToList()
                    );
                    CreateOlympiadsWindow_tmp.ShowDialog();
                });
            }
        }
        //---------------------------------CreateOlympiadsWindow
        private ObservableCollection<string> _listAllSport;
        public ObservableCollection<string> ListAllSport
        {
            get { return _listAllSport; }
            set
            {
                _listAllSport = value;
                OnPropertyChanged(nameof(_listAllSport));
            }
        }
        //
        private ObservableCollection<string> _listAllCountry;
        public ObservableCollection<string> ListAllCountry
        {
            get { return _listAllCountry; }
            set
            {
                _listAllCountry = value;
                OnPropertyChanged(nameof(_listAllCountry));
            }
        }

        private ObservableCollection<string> _listAllParticipant;
        public ObservableCollection<string> ListAllParticipant
        {
            get { return _listAllParticipant; }
            set
            {
                _listAllParticipant = value;
                OnPropertyChanged(nameof(_listAllParticipant));
            }
        }
        private BaseCommand _buttonCreateFullOlympiad;
        public BaseCommand ButtonCreateFullOlympiad
        {
            get
            {
                return _buttonCreateFullOlympiad ??= new BaseCommand(a =>
                {
                    if (string.IsNullOrWhiteSpace(createNewOlympiad.Year.ToString()) || !int.TryParse(createNewOlympiad.Year.ToString(), out int year) || year < 1896 || year > DateTime.Now.Year)
                    {
                        MessageBox.Show("Будь ласка, вкажіть коректний рік (між 1896 та поточним).");
                        return;
                    }

                    if (string.IsNullOrWhiteSpace(createNewOlympiad.CountryInfo.Country_Name))
                    {
                        MessageBox.Show("Будь ласка, оберіть країну.");
                        return;
                    }

                    if (string.IsNullOrWhiteSpace(createNewOlympiad.SportsInfo.Sport_Name))
                    {
                        MessageBox.Show("Будь ласка, оберіть вид спорту.");
                        return;
                    }

                    if (string.IsNullOrWhiteSpace(createNewOlympiad.ParticipantsInfo.FullName))
                    {
                        MessageBox.Show("Будь ласка, оберіть учасника.");
                        return;
                    }

                    if (createLocalResult.Gold_Medal < 0 || createLocalResult.Silver_Medal < 0 || createLocalResult.Bronze_Medal < 0)
                    {
                        MessageBox.Show("Кількість медалей не може бути від’ємною.");
                        return;
                    }

                    if (createLocalResult.Position <= 0)
                    {
                        MessageBox.Show("Позиція має бути більше нуля.");
                        return;
                    }

                    if (createLocalResult.DateAchieved > DateTime.Now || createLocalResult.DateAchieved < new DateTime(1896, 1, 1))
                    {
                        MessageBox.Show("Будь ласка, вкажіть коректну дату (між 1896 роком і сьогоднішнім днем).");
                        return;
                    }

                    createNewOlympiad.CountryInfo = GetAllCountry
                        .Where(b => b.Country_Name == createNewOlympiad.CountryInfo.Country_Name)
                        .First();
                    createNewOlympiad.SportsInfo = GetAllSport
                        .Where(b => b.Sport_Name == createNewOlympiad.SportsInfo.Sport_Name)
                        .First();
                    createNewOlympiad.ParticipantsInfo = GetAllParticipant
                        .Where(b => b.FullName == createNewOlympiad.ParticipantsInfo.FullName)
                        .First();
                    createNewOlympiad.ResultsInfo = createLocalResult;

                    _olymsService.createOlympics(createNewOlympiad);
                    GetAllOlympiads.Add(createNewOlympiad);
                    CreateOlympiadsWindow_tmp?.Close();
                });
            }
        }

        public Olympics_ModelBLL createNewOlympiad{ get; set; }
        public Result_ModelBLL createLocalResult{ get; set; }

        //---------------------------------
        private ObservableCollection<CountryOlympicsStats> _countryOlympicsStats;

        public ObservableCollection<CountryOlympicsStats> CountryOlympicsStats
        {
            get { return _countryOlympicsStats; }
            set
            {
                _countryOlympicsStats = value;
                OnPropertyChanged(nameof(CountryOlympicsStats));
            }
        }
        //---------------------------------allSport
        public Sport_ModelBLL createNewSport{ get; set; }
        private BaseCommand _buttonCreateFullSport;
        public BaseCommand ButtonCreateFullSport
        {
            get
            {
                return _buttonCreateFullSport ??= new BaseCommand(a =>
                {
                    _olymsService.createSport(createNewSport);
                    GetAllSport.Add(createNewSport);
                });
            }
        }

        public Sport_ModelBLL deleteSport_tmp { get; set; }
        private BaseCommand _deleteSelectedSportsCommand;
        public BaseCommand DeleteSelectedSportsCommand
        {
            get
            {
                return _deleteSelectedSportsCommand ??= new BaseCommand(a =>
                {
                    _olymsService.removeSport(deleteSport_tmp.Id);
                    GetAllSport.Remove(deleteSport_tmp);
                    deleteSport_tmp = new Sport_ModelBLL();
                });
            }
        }

        //---------------------------------AllCountry
        public Country_ModelBLL createNewCountry { get; set; }
        private BaseCommand _buttonCreateFullCountry;
        public BaseCommand ButtonCreateFullCountry
        {
            get
            {
                return _buttonCreateFullCountry ??= new BaseCommand(a =>
                {
                    _olymsService.createCountry(createNewCountry);
                    GetAllCountry.Add(createNewCountry);
                });
            }
        }

        public Country_ModelBLL deleteCountry_tmp { get; set; }
        private BaseCommand _deleteSelectedCountryCommand;
        public BaseCommand DeleteSelectedCountryCommand
        {
            get
            {
                return _deleteSelectedCountryCommand ??= new BaseCommand(a =>
                {
                    _olymsService.removeCountry(deleteCountry_tmp.Id);
                    GetAllCountry.Remove(deleteCountry_tmp);
                    deleteCountry_tmp = new Country_ModelBLL();
                });
            }
        }
        //---------------------------------AllParticipant
        public Participant_ModelBLL createNewParticipant { get; set; }
        private BaseCommand _buttonCreateFullParticipant;
        public BaseCommand ButtonCreateFullParticipant
        {
            get
            {
                return _buttonCreateFullParticipant ??= new BaseCommand(a =>
                {
                    _olymsService.createParticipant(createNewParticipant);
                    GetAllParticipant.Add(createNewParticipant);
                });
            }
        }

        public Participant_ModelBLL deleteParticipant_tmp { get; set; }
        private BaseCommand _deleteSelectedParticipantCommand;
        public BaseCommand DeleteSelectedParticipantCommand
        {
            get
            {
                return _deleteSelectedParticipantCommand ??= new BaseCommand(a =>
                {
                    _olymsService.removeParticipant(deleteParticipant_tmp.Id);
                    GetAllParticipant.Remove(deleteParticipant_tmp);
                    deleteParticipant_tmp = new Participant_ModelBLL();
                });
            }
        }
        //---------------------------------

        public MainPage_ViewModel(IOlimpiada_BLL<
            Olympics_ModelBLL,
            Country_ModelBLL,
            Participant_ModelBLL,
            Result_ModelBLL,
            Sport_ModelBLL> service, IUser_BLL<User_Model_BLL> user)
        {
            _olymsService = service;
            _userService = user;
            MainUser = _userService.activiti_user;

            GetAllOlympiads = new ObservableCollection<Olympics_ModelBLL>(_olymsService.getAllOlympics());
            GetAllCountry = new ObservableCollection<Country_ModelBLL>(_olymsService.getAllCountry());
            GetAllParticipant = new ObservableCollection<Participant_ModelBLL>(_olymsService.getAllParticipant());
            //GetAllResult = new ObservableCollection<Result_ModelBLL>(_olymsService.getAll)
            GetAllSport = new ObservableCollection<Sport_ModelBLL>(_olymsService.getAllSport());

            deleteOlympiad_tmp = new Olympics_ModelBLL();
            deleteSport_tmp = new Sport_ModelBLL();
            createNewSport = new Sport_ModelBLL();

            createNewCountry = new Country_ModelBLL();
            deleteCountry_tmp = new Country_ModelBLL();

            createNewParticipant = new Participant_ModelBLL();
            deleteParticipant_tmp = new Participant_ModelBLL();


            ////////// 
            createNewOlympiad = new Olympics_ModelBLL();
                createNewOlympiad.ParticipantsInfo = new Participant_ModelBLL();
                createNewOlympiad.ResultsInfo = new Result_ModelBLL();
                createNewOlympiad.CountryInfo = new Country_ModelBLL();
                createNewOlympiad.SportsInfo = new Sport_ModelBLL();
            createLocalResult = new Result_ModelBLL();
            //////////////////
            //AddOlympiad();
            var result = GetAllOlympiads
                .GroupBy(o => o.CountryInfo.Country_Name)
                .Select(group => new
                {
                    CountryName = group.Key,
                    HostCount = group.Count()
                })
                .OrderByDescending(result => result.HostCount)
                .FirstOrDefault();
            CountryOlympicsStats = new ObservableCollection<CountryOlympicsStats>
            {
                new CountryOlympicsStats
                {
                    CountryName = result.CountryName,
                    HostCount = result.HostCount
                }
            };

        }
        //---------------------------------


        private void AddOlympiad()
        {
            Country_ModelBLL new_country = new Country_ModelBLL
            {
                Country_Name = "United States",
                City_Name = "Los Angeles",
                Short_Name = "USA",
                HostCount = 4
            };
            Sport_ModelBLL new_sport = new Sport_ModelBLL
            {
                Sport_Name = "Basketball",
                Description = "A team sport played on a rectangular court",
                ParticipantCount = 10
            };
            Result_ModelBLL new_result = new Result_ModelBLL
            {
                Gold_Medal = 10,
                Silver_Medal = 5,
                Bronze_Medal = 3,
                Position = 1,
                DateAchieved = DateTime.Parse("2024-01-01"),
            };
            Participant_ModelBLL new_participants = new Participant_ModelBLL
            {
                FullName = "John Doe",
                Country = "USA",
                DateOfBirth = DateTime.Parse("1990-05-05"),
            };
            var olympiad = new Olympics_ModelBLL
            {
                Year = 2024,
                IsSeasonWinter = false,
                CountryInfo = new_country,
                SportsInfo = new_sport,
                ResultsInfo = new_result,
                ParticipantsInfo = new_participants
            };
            _olymsService.createOlympics(olympiad);
            ////////////////////////////
            Country_ModelBLL new_country1 = new Country_ModelBLL
            {
                Country_Name = "Ukraine",
                City_Name = "Kyiv",
                Short_Name = "UA",
                HostCount = 1
            };
            Sport_ModelBLL new_sport1 = new Sport_ModelBLL
            {
                Sport_Name = "Swimming",
                Description = "An individual or team racing sport",
                ParticipantCount = 8
            };
            Result_ModelBLL new_result1 = new Result_ModelBLL
            {
                Gold_Medal = 7,
                Silver_Medal = 8,
                Bronze_Medal = 4,
                Position = 2,
                DateAchieved = DateTime.Parse("2023-07-15"),
            };
            Participant_ModelBLL new_participants1 = new Participant_ModelBLL
            {
                FullName = "Anna Ivanova",
                Country = "UA",
                DateOfBirth = DateTime.Parse("1995-08-12"),
            };
            var olympiad1 = new Olympics_ModelBLL
            {
                Year = 2020,
                IsSeasonWinter = true,
                CountryInfo = new_country1,
                SportsInfo = new_sport1,
                ResultsInfo = new_result1,
                ParticipantsInfo = new_participants1
            };
            _olymsService.createOlympics(olympiad1);
            //////////////////
            Country_ModelBLL new_country2 = new Country_ModelBLL
            {
                Country_Name = "France",
                City_Name = "Paris",
                Short_Name = "FR",
                HostCount = 3
            };
            Sport_ModelBLL new_sport2 = new Sport_ModelBLL
            {
                Sport_Name = "Athletics",
                Description = "Track and field sports",
                ParticipantCount = 30
            };
            Result_ModelBLL new_result2 = new Result_ModelBLL
            {
                Gold_Medal = 5,
                Silver_Medal = 6,
                Bronze_Medal = 7,
                Position = 3,
                DateAchieved = DateTime.Parse("2022-05-20"),
            };
            Participant_ModelBLL new_participants2 = new Participant_ModelBLL
            {
                FullName = "Pierre Dubois",
                Country = "FR",
                DateOfBirth = DateTime.Parse("1988-03-22"),
            };
            var olympiad2 = new Olympics_ModelBLL
            {
                Year = 2016,
                IsSeasonWinter = false,
                CountryInfo = new_country2,
                SportsInfo = new_sport2,
                ResultsInfo = new_result2,
                ParticipantsInfo = new_participants2
            };
            _olymsService.createOlympics(olympiad2);
            //////////////////
            Country_ModelBLL new_country3 = new Country_ModelBLL
            {
                Country_Name = "Japan",
                City_Name = "Tokyo",
                Short_Name = "JP",
                HostCount = 2
            };
            Sport_ModelBLL new_sport3 = new Sport_ModelBLL
            {
                Sport_Name = "Gymnastics",
                Description = "Exercises requiring strength, flexibility, and balance",
                ParticipantCount = 15
            };
            Result_ModelBLL new_result3 = new Result_ModelBLL
            {
                Gold_Medal = 8,
                Silver_Medal = 10,
                Bronze_Medal = 6,
                Position = 1,
                DateAchieved = DateTime.Parse("2021-11-11"),
            };
            Participant_ModelBLL new_participants3 = new Participant_ModelBLL
            {
                FullName = "Yuki Tanaka",
                Country = "JP",
                DateOfBirth = DateTime.Parse("1992-10-30"),
            };
            var olympiad3 = new Olympics_ModelBLL
            {
                Year = 2012,
                IsSeasonWinter = false,
                CountryInfo = new_country3,
                SportsInfo = new_sport3,
                ResultsInfo = new_result3,
                ParticipantsInfo = new_participants3
            };
            _olymsService.createOlympics(olympiad3);
            //////////////////
            Country_ModelBLL new_country4 = new Country_ModelBLL
            {
                Country_Name = "Canada",
                City_Name = "Vancouver",
                Short_Name = "CA",
                HostCount = 2
            };
            Sport_ModelBLL new_sport4 = new Sport_ModelBLL
            {
                Sport_Name = "Ice Hockey",
                Description = "A team sport played on ice",
                ParticipantCount = 20
            };
            Result_ModelBLL new_result4 = new Result_ModelBLL
            {
                Gold_Medal = 3,
                Silver_Medal = 4,
                Bronze_Medal = 5,
                Position = 4,
                DateAchieved = DateTime.Parse("2020-03-03"),
            };
            Participant_ModelBLL new_participants4 = new Participant_ModelBLL
            {
                FullName = "Emily Smith",
                Country = "CA",
                DateOfBirth = DateTime.Parse("1996-07-15"),
            };
            var olympiad4 = new Olympics_ModelBLL
            {
                Year = 2008,
                IsSeasonWinter = true,
                CountryInfo = new_country4,
                SportsInfo = new_sport4,
                ResultsInfo = new_result4,
                ParticipantsInfo = new_participants4
            };
            _olymsService.createOlympics(olympiad4);

        }

    }
    public class CountryOlympicsStats
    {
        public string CountryName { get; set; }
        public int HostCount { get; set; }
    }

}
