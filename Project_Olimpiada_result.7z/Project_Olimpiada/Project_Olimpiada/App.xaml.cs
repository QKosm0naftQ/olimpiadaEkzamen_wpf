﻿using System;
using System.Configuration;
using System.Data;
using System.Windows;
using BLL.Configuration;
using BLL.Interface;
using BLL.Model;
using BLL.Service;
using DLL.Interface;
using DLL.Model;
using Microsoft.Extensions.DependencyInjection;
using Project_Olimpiada.GeneralWindow.Pages;
using Project_Olimpiada.ViewModels_login;
using Project_Olimpiada.ViewModels_MainProggram;
using Project_Olimpiada.WindowGeneral;
using Project_Olimpiada.WindowGeneral.Pages;
namespace Project_Olimpiada
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>

    public partial class App : Application
    {
        private IServiceProvider _serviceProvider;
        public App()
        {
            var service = new ServiceCollection();
            ConfigurationService(service);
            _serviceProvider = service.BuildServiceProvider();
        }

        private void ConfigurationService(ServiceCollection services)
        {
            services.AddTransient(typeof(IUser_BLL<User_Model_BLL>) , typeof(User_service));
            services.AddTransient(typeof(IOlimpiada_BLL<
            Olympics_ModelBLL,
            Country_ModelBLL,
            Participant_ModelBLL,
            Result_ModelBLL,
            Sport_ModelBLL>) , typeof(Olympiada_service));

            //
            services.AddTransient(typeof(LoginWindow));
            services.AddTransient(typeof(Login_windowViewModel));
            //
            services.AddTransient(typeof(WindowMain));
            services.AddTransient(typeof(MainPage_ViewModel));
            services.AddTransient(typeof(MainPage));

            //
            ConfigurationBLL.ConfigurationServiceCollection(services, ConfigurationManager.ConnectionStrings["default"].ConnectionString);
        }

        private void OnStartUp(object sender, StartupEventArgs e)
        {
            var loginWind = _serviceProvider.GetService<LoginWindow>();
            loginWind.Show();
            //var generalWind = _serviceProvider.GetService<WindowMain>();
            //generalWind.Show();
        }

    }

}
