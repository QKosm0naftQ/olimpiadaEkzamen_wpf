﻿using BLL.Interface;
using BLL.Model;
using BLL.Service;
using Microsoft.Extensions.DependencyInjection;
using Project_Olimpiada.Commands;
using Project_Olimpiada.WindowGeneral;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
using System.Windows;

namespace Project_Olimpiada.ViewModels_login
{
    public class Login_windowViewModel : INotifyPropertyChanged
    {
        private IUser_BLL<User_Model_BLL> _service;
        private IOlimpiada_BLL<
            Olympics_ModelBLL,
            Country_ModelBLL,
            Participant_ModelBLL,
            Result_ModelBLL,
            Sport_ModelBLL> _olympiadaService;
        private BaseCommand _commandLogin;
        public event PropertyChangedEventHandler? PropertyChanged;
        public User_Model_BLL TempUser { get; set; }
        public Login_windowViewModel(IUser_BLL<User_Model_BLL> service , IOlimpiada_BLL<
            Olympics_ModelBLL,
            Country_ModelBLL,
            Participant_ModelBLL,
            Result_ModelBLL,
            Sport_ModelBLL> olympiadaService)
        {
            _service = service;
            _olympiadaService = olympiadaService;
            TempUser = new User_Model_BLL(); 
        }
        public BaseCommand CommandLogin
        {
            get
            {
                return _commandLogin ??= new BaseCommand(a =>
                {
                    if (_service.isEnableAccount(TempUser.Username, TempUser.Password))
                    {
                        _service.activiti_user = _service.getUser(TempUser.Username, TempUser.Password);
                        var currentWindow = Application.Current.MainWindow;

                        var newWindow = new WindowMain(_olympiadaService, _service);
                        Application.Current.MainWindow = newWindow;
                        newWindow.Show();

                        currentWindow?.Close();

                    }
                });
            }
        }

    }
}
