﻿using BLL.Interface;
using BLL.Model;
using DLL.Interface;
using Project_Olimpiada.GeneralWindow.Pages;
using Project_Olimpiada.ViewModels_MainProggram;
using Project_Olimpiada.ViewModels_login;
using Project_Olimpiada.WindowGeneral.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BLL.Service;

namespace Project_Olimpiada.WindowGeneral
{
    /// <summary>
    /// Interaction logic for WindowMain.xaml
    /// </summary>
    public partial class WindowMain : Window
    {
        private IOlimpiada_BLL<
            Olympics_ModelBLL,
            Country_ModelBLL,
            Participant_ModelBLL,
            Result_ModelBLL,
            Sport_ModelBLL> _olimService;
        private IUser_BLL<User_Model_BLL> _userService;
        private MainPage_ViewModel mainPageViewModel;
        public WindowMain(IOlimpiada_BLL<
            Olympics_ModelBLL,
            Country_ModelBLL,
            Participant_ModelBLL,
            Result_ModelBLL,
            Sport_ModelBLL> olimService , IUser_BLL<User_Model_BLL> userService )
        {
            InitializeComponent();
            _olimService = olimService;
            _userService = userService;
            mainPageViewModel = new MainPage_ViewModel(_olimService, _userService);
            MainFrame.Navigate(new MainPage(mainPageViewModel));
        }

        private void bt_medal_zalik_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new TableMedalZalikPage(mainPageViewModel));
        }

        private void bt_main_page_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new MainPage(mainPageViewModel));
        }

        private void bt_nameCountryMostHost_Click(object sender, RoutedEventArgs e)
        {
            //MainFrame.Navigate(new OlympicHostCountriesPage(mainPageViewModel));

        }
        private void bt_all_olympiads_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AllOlympiadsPage(mainPageViewModel));
        }

        private void bt_medalistZsport_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new MedalisZSport(mainPageViewModel));
        }

        private void bt_groupTeamCountry_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new groupTeamCountryPage(mainPageViewModel));

        }

        private void bt_countryMostGospodarka_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new CountryMostGospodarkaPage(mainPageViewModel));
        }
        private void bt_all_sport_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AllSportsPage(mainPageViewModel));
        }

        private void bt_all_country_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AllCountryPage(mainPageViewModel));

        }

        private void bt_all_patricipant_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AllParticipantPage(mainPageViewModel));

        }
    }
}
