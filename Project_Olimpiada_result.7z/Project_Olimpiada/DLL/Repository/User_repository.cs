﻿using DLL.Interface;
using DLL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.Repository
{
    public class User_repository : IUser_DLL<User_Model_DLL>
    {
        private Olimpiada_context _context;
        public User_repository(Olimpiada_context context)
        {
            _context = context;
        }
        public User_Model_DLL activiti_user { get; set; }

        public void ChangeUserData_(int id,string? username = null, string? password = null, string? secretWord = null)
        {
            var user = _context.User_dbset.Where(a => a.ID == id).First();
            if (user != null)
            {
                if (!string.IsNullOrEmpty(username))
                {
                    user.Username = username;
                }

                if (!string.IsNullOrEmpty(password))
                {
                    user.Password = password;
                }

                if (!string.IsNullOrEmpty(secretWord))
                {
                    user.SecretWord = secretWord;
                }
            }
        }

        public void CreateUser(User_Model_DLL user)
        {
            _context.User_dbset.Add(user);
        }

        public bool DoesUserExist(string username)
        {
            return _context.User_dbset.Any(a => a.Username == username);
        }

        public User_Model_DLL getUser(int id)
        {
            return _context.User_dbset.Where(a => a.ID == id).First();
        }
        public User_Model_DLL getUser(string username, string password)
        {
            return _context.User_dbset.Where(a => a.Username == username && a.Password == password).First();
        }

        public bool isEnableAccount(string username, string password)
        {
            return _context.User_dbset.Any(a => a.Username == username && a.Password == password);
        }

        public void RemoveUser(int id)
        {

            _context.User_dbset.Remove(_context.User_dbset.Where(a=>a.ID == id).First());
            _context.SaveChanges();
        }

        public void RemoveUser(User_Model_DLL user)
        {
            _context.User_dbset.Remove(user);
            _context.SaveChanges();
        }

        public void ResetPassword(string username, string secretWord, string newPassword)
        {
            var user = _context.User_dbset.Where(a => a.Username == username && a.SecretWord == secretWord).First();
            if (user != null)
            {
                user.Password = newPassword;
            }
        }
    }
}
