﻿using DLL.Interface;
using DLL.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.Repository
{
    public class Olympiada_repository : 
        IOlimpiada_DLL<
            Olympics_ModelDLL,
            Country_ModelDLL,
            Participant_ModelDLL,
            Result_ModelDLL,
            Sport_ModelDLL>
    {
        private Olimpiada_context _context;
        public Olympiada_repository(Olimpiada_context ol_context) 
        {
            this._context = ol_context;
        }

        public void createOlympics(Olympics_ModelDLL olympics)
        {
            _context.Olympics_dbset.Add(olympics);
            _context.SaveChanges();
        }
        public void removeOlympics(int id)
        {
            _context.Olympics_dbset.Remove(_context.Olympics_dbset.Where(a=>a.Id == id).First());
            _context.SaveChanges();
        }
        public void createSport(Sport_ModelDLL sport)
        {
            _context.Sport_dbset.Add(sport);
            _context.SaveChanges();
        }
        public void removeSport(int id)
        {
            _context.Sport_dbset.Remove(_context.Sport_dbset.Where(a => a.Id == id).First());
            _context.SaveChanges();
        }

        public Olympics_ModelDLL getElementOlympics(int id)
        {
            return _context.Olympics_dbset.Where(a=>a.Id == id).First();
        }
        public IEnumerable<Olympics_ModelDLL> getAllOlympics()
        {
            return _context.Olympics_dbset
                .Include(o => o.CountryInfo)            // Завантаження інформації про країну
                .Include(o => o.SportsInfo)            // Завантаження спорту, пов’язаного з олімпіадою
                .Include(o => o.ResultsInfo)           // Завантаження інформації про результати
                .Include(o => o.ParticipantsInfo);     // Завантаження інформації про учасників
        }

        public IEnumerable<Country_ModelDLL> getAllCountry()
        {
            return _context.Country_dbset;
        }

        public IEnumerable<Participant_ModelDLL> getAllParticipant()
        {
            return _context.Participant_dbset;
        }

        public IEnumerable<Sport_ModelDLL> getAllSport()
        {
            return _context.Sport_dbset;
        }

        public void createCountry(Country_ModelDLL olympics)
        {
            _context.Country_dbset.Add(olympics);
            _context.SaveChanges();
        }

        public void removeCountry(int id)
        {
            _context.Country_dbset.Remove(_context.Country_dbset.Where(a => a.Id == id).First());
            _context.SaveChanges();
        }

        public void createParticipant(Participant_ModelDLL olympics)
        {
            _context.Participant_dbset.Add(olympics);
            _context.SaveChanges();
        }

        public void removeParticipant(int id)
        {
            _context.Participant_dbset.Remove(_context.Participant_dbset.Where(a => a.Id == id).First());
            _context.SaveChanges();
        }
    }
}
