﻿using DLL.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL
{
    public class Olimpiada_context : DbContext
    {
        public Olimpiada_context(DbContextOptions<Olimpiada_context> options) : base(options)
        {
            Database.EnsureCreated();
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // CountryInfo
            modelBuilder.Entity<Olympics_ModelDLL>()
                .HasOne(o => o.CountryInfo)
                .WithMany()
                .OnDelete(DeleteBehavior.Restrict); // Забороняємо каскадне видалення

            // SportsInfo
            modelBuilder.Entity<Olympics_ModelDLL>()
                .HasOne(o => o.SportsInfo)
                .WithMany()
                .OnDelete(DeleteBehavior.Restrict);

            // ResultsInfo
            modelBuilder.Entity<Olympics_ModelDLL>()
                .HasOne(o => o.ResultsInfo)
                .WithMany()
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Olympics_ModelDLL>()
                .HasOne(o => o.ParticipantsInfo)
                .WithMany()
                .OnDelete(DeleteBehavior.Restrict);
            //////////////////////////////////////////////

        }

        public DbSet<Olympics_ModelDLL> Olympics_dbset { get; set; }
        public DbSet<Country_ModelDLL> Country_dbset { get; set; }
        public DbSet<Result_ModelDLL> Result_dbset { get; set; }
        public DbSet<Sport_ModelDLL> Sport_dbset { get; set; }
        public DbSet<Participant_ModelDLL> Participant_dbset { get; set; }
        public DbSet<User_Model_DLL> User_dbset { get; set; }
    }
}

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    //modelBuilder.Entity<Olympics_ModelDLL>()
        //    //    .HasMany(o => o.SportsInfo)
        //    //    .WithMany(s => s.Olympics)
        //    //    .UsingEntity(j => j.ToTable("OlympicsSports"));
        //    //modelBuilder.Entity<Olympics_ModelDLL>()
        //    //    .HasMany(o => o.ParticipantsInfo)
        //    //    .WithMany(s => s.Olympics)
        //    //    .UsingEntity(j => j.ToTable("OlympicsParticipants"));
        //    //modelBuilder.Entity<Olympics_ModelDLL>()
        //    //    .HasMany(o => o.ResultsInfo)
        //    //    .WithMany(s => s.Olympics)
        //    //    .UsingEntity(j => j.ToTable("OlympicsResults"));
        //    ///////////////////////////////////////////////////////////
        //    //modelBuilder.Entity<Participant_ModelDLL>()
        //    //    .Ignore(p => p.Result_ModelDLLId);
        //    //modelBuilder.Entity<Participant_ModelDLL>()
        //    //    .Ignore(p => p.ResultInfo);
        //}