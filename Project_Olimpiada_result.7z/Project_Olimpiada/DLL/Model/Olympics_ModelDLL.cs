﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.Model
{
    public class Olympics_ModelDLL
    {
        public int Id { get; set; }
        public int Year { get; set; }
        public bool IsSeasonWinter { get; set; } // "Літня" або "Зимова"
        public Sport_ModelDLL SportsInfo { get; set; }
        public Result_ModelDLL ResultsInfo { get; set; }
        public Participant_ModelDLL ParticipantsInfo { get; set; }
        public Country_ModelDLL CountryInfo { get; set; }
    }

}
