﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.Model
{
    public class Sport_ModelDLL
    {
        public int Id { get; set; }
        public string Sport_Name { get; set; }
        public string Description { get; set; }
        public int ParticipantCount { get; set; }
    }
        //public ICollection<Olympics_ModelDLL> Olympics { get; set; } = new List<Olympics_ModelDLL>();
}
