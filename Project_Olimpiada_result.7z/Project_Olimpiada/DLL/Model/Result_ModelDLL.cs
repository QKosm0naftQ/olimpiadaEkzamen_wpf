﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.Model
{
    public class Result_ModelDLL
    {
        public int Id { get; set; }
        public int Gold_Medal { get; set; }  
        public int Silver_Medal { get; set; }  
        public int Bronze_Medal { get; set; }  
        public int Position { get; set; } 
        public DateTime DateAchieved { get; set; } 
    }
        //public Sport_ModelDLL SportInfo { get; set; }
        //public ICollection<Participant_ModelDLL> ParticipantsInfo { get; set; } = new List<Participant_ModelDLL>();
        //public ICollection<Olympics_ModelDLL> Olympics { get; set; } = new List<Olympics_ModelDLL>();
}
