﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.Model
{
    public class Participant_ModelDLL
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Country { get; set; }
        public DateTime DateOfBirth { get; set; }
    }
        //public Sport_ModelDLL SportInfo { get; set; }
        //public ICollection<Olympics_ModelDLL> Olympics { get; set; } = new List<Olympics_ModelDLL>();
        //public int Result_ModelDLLId { get; set; }
        //public Result_ModelDLL ResultInfo { get; set; }
}
