﻿ INSERT INTO [User_dbset] (Username, Password, SecretWord, Role)
VALUES ('user', 'user', 'mySecretWord', 'User');
 INSERT INTO [User_dbset] (Username, Password, SecretWord, Role)
VALUES ('admin', 'admin', 'mySecretWord', 'Admin');
select * from [User_dbset];

 INSERT INTO [Country_dbset]
 VALUES 
 ('Ukraine','Kiev','UA',1),
 ('Itali','Rom','IT',3),
 ('France','Paris','FR',2),
 ('America','Vashinkton','USA',4)

 INSERT INTO [Sport_dbset]
 VALUES
 ('Golf','Good game for solo' , 1),
 ('BascetBool','Good game for 4' , 4),
 ('Tenis','Good game ' , 4)

INSERT INTO [Participant_dbset] (FullName,Country,DateOfBirth,SportInfoId)
VALUES 
('roma','bebra','2000-01-01' ,1);

select * from [Country_dbset];
select * from [Sport_dbset];
select * from [Participant_dbset];
select * from [Result_dbset];
select * from [Olympics_dbset];
ALTER TABLE [Olympics_dbset]
DROP COLUMN Country_ModelDLLId;
---------------------------------------------------------------------------------
-- Вставка записів у таблицю Country_dbset
INSERT INTO Country_dbset (Country_Name, City_Name, Short_Name, HostCount) VALUES
('United States', 'Los Angeles', 'USA', 4),
('Ukraine', 'Kyiv', 'UA', 1),
('France', 'Paris', 'FR', 3),
('Japan', 'Tokyo', 'JP', 2),
('Canada', 'Vancouver', 'CA', 2);

-- Вставка записів у таблицю Sport_dbset
INSERT INTO Sport_dbset (Sport_Name, Description, ParticipantCount) VALUES
('Basketball', 'A team sport played on a rectangular court', 10),
('Swimming', 'An individual or team racing sport', 8),
('Athletics', 'Track and field sports', 30),
('Gymnastics', 'Exercises requiring strength, flexibility, and balance', 15),
('Ice Hockey', 'A team sport played on ice', 20);

-- Вставка записів у таблицю Result_dbset
INSERT INTO Result_dbset (Gold_Medal, Silver_Medal, Bronze_Medal, Position, DateAchieved) VALUES
(10, 5, 3, 1, '2024-01-01'),
(7, 8, 4, 2, '2023-07-15'),
(5, 6, 7, 3, '2022-05-20'),
(8, 10, 6, 1, '2021-11-11'),
(3, 4, 5, 4, '2020-03-03');

-- Вставка записів у таблицю Olympics_dbset
INSERT INTO Olympics_dbset (Year, IsSeasonWinter,CountryInfoId, SportsInfoId,ResultsInfoId,ParticipantsInfoId) VALUES
(2024, 0,  1, 1,1,1),
(2020, 1,  2, 2,2,2),
(2016, 0,  3, 3,3,3),
(2012, 0,  4, 4,4,4),
(2008, 1,  5, 5,5,5);

-- Вставка записів у таблицю Participant_dbset
INSERT INTO Participant_dbset (FullName, Country, DateOfBirth) VALUES
('John Doe', 'USA', '1990-05-05'),
('Anna Ivanova', 'UA', '1995-08-12'),
('Pierre Dubois', 'FR', '1988-03-22'),
('Yuki Tanaka', 'JP', '1992-10-30'),
('Emily Smith', 'CA', '1996-07-15');

------
INSERT INTO Olympics_dbset (Year, IsSeasonWinter,CountryInfoId, SportsInfoId,ResultsInfoId,ParticipantsInfoId) VALUES
(2000, 0,  1, 2,3,4)